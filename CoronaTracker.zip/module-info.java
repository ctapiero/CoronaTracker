/**
 * 
 */
/**
 * @author Cristian Tapiero
 *
 */
module coronacorona {
	requires java.desktop;
	requires json.simple;
}